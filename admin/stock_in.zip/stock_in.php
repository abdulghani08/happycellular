<?php
session_start();
require_once '../api/auth_helper.php';

// Proteksi halaman: Hanya admin yang boleh masuk
restrictTo(['admin']);
require_once '../connection.php';

$produk = [];

$q = mysqli_query(
    $koneksi,
    "SELECT *
     FROM master_produk
     WHERE aktif = 1
     ORDER BY nama ASC"
);

while($r = mysqli_fetch_assoc($q))
{
    $produk[] = $r;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes, viewport-fit=cover">
    <title>Stock In · Happy Cellular</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@ericblade/quagga2/dist/quagga.min.js"></script>

    <style>
        /* CSS VARIABEL IDENTIK DENGAN HOME_ADMIN.PHP */
        :root {
            --bg-body: #F4F7FA;
            --surface-card: #FFFFFF;
            --primary-dongker: #1E4A7A;
            --primary-dongker-soft: #EEF4FA;
            --accent-blue: #3B82F6;
            --text-main: #1E293B;
            --text-muted: #64748B;
            --success-green: #10B981;
            --bottom-nav-height: 72px;
            --sidebar-width: 260px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg-body);
            min-height: 100vh;
            color: var(--text-main);
            padding-bottom: calc(var(--bottom-nav-height) + 2rem);
        }

        /* NAVBAR ATAS */
        .navbar-top {
            background: var(--surface-card);
            padding: 1.2rem 1.5rem 0.8rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.02);
        }
        .logo-area { display: flex; align-items: center; gap: 10px; }
        .navbar-logo { width: 32px; height: 32px; object-fit: contain; border-radius: 8px; }
        .logo-text { font-weight: 800; font-size: 1.3rem; color: var(--primary-dongker); letter-spacing: -0.5px; }
        .logo-text small { font-size: 0.75rem; font-weight: 500; color: var(--text-muted); display: block; margin-top: -2px; }
        
        .user-badge {
            background: var(--primary-dongker-soft);
            padding: 8px 16px;
            border-radius: 20px;
            color: var(--primary-dongker);
            font-weight: 700;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 6px;
            border: none;
        }

        /* MAIN WRAPPER */
        .main-wrapper {
            max-width: 600px;
            margin: 0 auto;
            padding: 1rem 1.2rem;
        }

        /* BUTTON SCAN HERO */
        .btn-scan-hero {
            background: linear-gradient(135deg, var(--primary-dongker), var(--accent-blue));
            border: none;
            color: white;
            border-radius: 20px;
            padding: 1.2rem;
            width: 100%;
            font-size: 1.1rem;
            font-weight: 700;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            box-shadow: 0 10px 25px -5px rgba(30, 74, 122, 0.3);
            transition: transform 0.2s;
            margin-bottom: 1.5rem;
        }
        .btn-scan-hero:active { transform: scale(0.97); }
        .btn-scan-hero i { font-size: 2rem; }

        /* FORM CARDS */
        .card-custom {
            background: var(--surface-card);
            border-radius: 20px;
            padding: 1.2rem;
            margin-bottom: 1.2rem;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.02);
            border: 1px solid rgba(0, 0, 0, 0.01);
        }
        .card-title-custom {
            font-size: 0.85rem;
            font-weight: 800;
            color: var(--primary-dongker);
            letter-spacing: 0.5px;
            text-transform: uppercase;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            margin-bottom: 1rem;
            border-bottom: 1px solid #F1F5F9;
            padding-bottom: 10px;
        }

        /* IMEI CHIP */
        .imei-chip {
            background: #f0fdf4;
            color: #10B981;
            border: 1px solid #bbf7d0;
            border-radius: 10px;
            padding: 8px 12px;
            font-weight: 700;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin: 4px;
        }
        .imei-chip .btn-del { color: #EF4444; cursor: pointer; padding: 2px; }

        /* FORM FLOATING ADJUSTMENTS */
        .form-floating > .form-control,
        .form-floating > .form-select {
            border-radius: 12px;
            border: 1px solid #E2E8F0;
            height: calc(3.5rem + 2px);
            padding: 1rem 0.75rem;
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-main);
        }
        .form-floating > .form-control:focus {
            border-color: var(--primary-dongker);
            box-shadow: 0 0 0 3px var(--primary-dongker-soft);
        }
        .form-floating > label { color: var(--text-muted); font-weight: 500; font-size: 0.85rem; }
        .form-control.uppercase { text-transform: uppercase; }

        /* PROFIT BADGE & UPLOAD */
        .profit-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 700;
            margin-top: 5px;
        }
        .upload-area {
            display: flex; gap: 15px; align-items: center; background: #F8FAFC;
            padding: 15px; border-radius: 12px; border: 2px dashed #E2E8F0;
        }
        .img-preview-box {
            width: 70px; height: 70px; background: white; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            border: 1px solid #E2E8F0; overflow: hidden; flex-shrink: 0;
        }
        .img-preview-box img { width: 100%; height: 100%; object-fit: cover; }

        /* SUMMARY BAR / ACTION BAR STICKY */
        .summary-bar {
            background: var(--surface-card);
            border-radius: 20px;
            padding: 1rem 1.2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.02);
            position: sticky;
            bottom: calc(var(--bottom-nav-height) + 12px);
            z-index: 100;
            margin-top: 1rem;
        }
        .btn-save {
            background: var(--primary-dongker);
            color: white;
            border-radius: 14px;
            padding: 14px 20px;
            font-weight: 700;
            font-size: 1rem;
            width: 100%;
            border: none;
            transition: 0.2s;
            box-shadow: 0 4px 12px rgba(30, 74, 122, 0.2);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }
        .btn-save:active { transform: scale(0.97); }

        /* BOTTOM NAVIGATION (Mobile) */
        .bottom-nav {
            position: fixed; bottom: 0; left: 0; right: 0;
            height: var(--bottom-nav-height); background: var(--surface-card);
            display: flex; justify-content: space-around; align-items: center;
            box-shadow: 0 -8px 30px rgba(0, 0, 0, 0.04); border-top: 1px solid #EDF2F7;
            z-index: 1050; padding-bottom: env(safe-area-inset-bottom, 0);
        }
        .nav-item {
            display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px;
            text-decoration: none; color: #A0AEC0; font-size: 0.7rem; font-weight: 600; flex: 1; height: 100%; transition: all 0.2s ease;
        }
        .nav-item i { font-size: 1.25rem; }
        .nav-item.active { color: var(--primary-dongker); }

        /* POPUP MENU LAINNYA */
        .more-menu-popup {
            position: fixed; bottom: calc(var(--bottom-nav-height) + 12px); left: 50%; transform: translateX(-50%) scale(0.95);
            width: calc(100% - 2.4rem); max-width: 500px; background: var(--surface-card); border-radius: 20px;
            box-shadow: 0 15px 35px rgba(30, 41, 59, 0.15); padding: 10px; display: none; grid-template-columns: repeat(2, 1fr);
            gap: 8px; z-index: 1100; opacity: 0; transition: all 0.2s ease;
        }
        .more-menu-popup.show { display: grid; transform: translateX(-50%) scale(1); opacity: 1; }
        .more-menu-popup a {
            padding: 12px; text-decoration: none; color: var(--text-main); font-weight: 600; font-size: 0.8rem;
            border-radius: 12px; display: flex; align-items: center; gap: 10px; background: #F8FAFC; cursor: pointer;
        }
        .more-menu-popup a i { color: var(--primary-dongker); font-size: 1rem; }
        .more-menu-popup a:hover { background: var(--primary-dongker-soft); }

        .popup-overlay { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.12); backdrop-filter: blur(2px); z-index: 1090; display: none; }
        .popup-overlay.show { display: block; }

        /* ====== DESKTOP SIDEBAR ====== */
        .desktop-sidebar { display: none; }

        @media (min-width: 992px) {
            body { padding-bottom: 0; display: flex; background: #F8FAFC; }
            .bottom-nav, .popup-overlay, .more-menu-popup { display: none !important; }
            .navbar-top { position: static; box-shadow: none; background: transparent; padding: 1.5rem 2rem 0; width: 100%; }
            .navbar-top .logo-area { display: none; }
            
            .desktop-sidebar {
                display: flex; flex-direction: column; width: var(--sidebar-width); background: var(--surface-card);
                height: 100vh; position: sticky; top: 0; border-right: 1px solid #E2E8F0; padding: 1.5rem; z-index: 1010;
            }
            .sidebar-brand { display: flex; align-items: center; gap: 10px; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid #F1F5F9; }
            .sidebar-menu { display: flex; flex-direction: column; gap: 5px; flex-grow: 1; }
            .sidebar-link {
                display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: var(--text-muted);
                text-decoration: none; font-weight: 600; font-size: 0.85rem; border-radius: 12px; transition: all 0.2s;
            }
            .sidebar-link i { font-size: 1.1rem; width: 20px; text-align: center; }
            .sidebar-link:hover, .sidebar-link.active { background: var(--primary-dongker-soft); color: var(--primary-dongker); }
            .sidebar-divider { height: 1px; background: #F1F5F9; margin: 10px 0; }

            .content-wrapper { flex-grow: 1; display: flex; flex-direction: column; min-width: 0; }
            .main-wrapper { max-width: 1200px; width: 100%; padding: 1.5rem 2rem; margin: 0; }
            .summary-bar { bottom: 20px; max-width: 600px; margin-left: auto; margin-right: auto; }
        }

        /* SCANNER MODAL UI/UX ENHANCEMENT */
        #scannerModal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #000; z-index: 10000; display: none; }
        .scanner-header {
            position: absolute; top: 0; left: 0; width: 100%; padding: 20px; display: flex; justify-content: space-between;
            z-index: 10001; background: linear-gradient(to bottom, rgba(0,0,0,0.8), transparent);
        }
        .btn-glass {
            background: rgba(255,255,255,0.2); backdrop-filter: blur(8px); border: none; color: white; border-radius: 30px; 
            padding: 10px 20px; font-weight: 600; cursor: pointer; font-size: 0.9rem; display: flex; align-items: center; gap: 8px; transition: all 0.2s;
        }
        .btn-glass:hover { background: rgba(255,255,255,0.3); }
        .btn-glass.bg-danger { background: rgba(239, 68, 68, 0.8) !important; }
        .btn-glass.bg-danger:hover { background: rgba(239, 68, 68, 1) !important; }
        
        #reader { width: 100%; height: 100%; overflow: hidden; }
        #reader video { object-fit: cover; width: 100%; height: 100%; }
        
        .scanner-overlay {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 10001; pointer-events: none;
            clip-path: polygon(0% 0%, 0% 100%, 100% 100%, 100% 0%, 0% 0%, calc(50% - 140px) calc(50% - 90px), calc(50% + 140px) calc(50% - 90px), calc(50% + 140px) calc(50% + 90px), calc(50% - 140px) calc(50% + 90px), calc(50% - 140px) calc(50% - 90px));
        }
        .scanner-reticle {
            position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 280px; height: 180px; z-index: 10002; pointer-events: none;
        }
        .scanner-reticle::before, .scanner-reticle::after, .scanner-reticle .corner-bottom::before, .scanner-reticle .corner-bottom::after {
            content: ''; position: absolute; width: 30px; height: 30px; border-color: #fff; border-style: solid; transition: border-color 0.3s;
        }
        .scanner-reticle::before { top: 0; left: 0; border-width: 4px 0 0 4px; border-top-left-radius: 12px; }
        .scanner-reticle::after { top: 0; right: 0; border-width: 4px 4px 0 0; border-top-right-radius: 12px; }
        .scanner-reticle .corner-bottom::before { bottom: 0; left: 0; border-width: 0 0 4px 4px; border-bottom-left-radius: 12px; }
        .scanner-reticle .corner-bottom::after { bottom: 0; right: 0; border-width: 0 4px 4px 0; border-bottom-right-radius: 12px; }
        
        .scan-line { position: absolute; top: 0; left: 0; width: 100%; height: 2px; background: #3B82F6; box-shadow: 0 0 10px #3B82F6; animation: scanAnim 2s ease-in-out infinite; }
        @keyframes scanAnim { 0%, 100% { top: 0; opacity: 0; } 10%, 90% { opacity: 1; } 50% { top: 100%; } }
        .scanner-helper-text { position: absolute; top: calc(50% + 120px); left: 50%; transform: translateX(-50%); color: white; font-weight: 500; font-size: 0.9rem; z-index: 10002; text-shadow: 0 2px 4px rgba(0,0,0,0.5); text-align: center; width: 100%; }
        .scanner-success .scanner-reticle::before, .scanner-success .scanner-reticle::after, .scanner-success .scanner-reticle .corner-bottom::before, .scanner-success .scanner-reticle .corner-bottom::after { border-color: #10B981; }

        /* Loading Overlay & Toast */
        #loadingOverlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(4px); z-index: 2000; display: none; align-items: center; justify-content: center; color: white; flex-direction: column; }
        .toast-container { position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 9999; }
        .toast-mini { background: var(--primary-dongker); color: white; border-radius: 30px; padding: 12px 24px; font-weight: 600; font-size: 0.9rem; display: flex; align-items: center; gap: 10px; margin-bottom: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); animation: slideDown 0.3s ease; }
        @keyframes slideDown { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    </style>
</head>
<body>

<div class="desktop-sidebar">
    <div class="sidebar-brand">
        <img src="asset/Happy.png" alt="Happy Cell" class="navbar-logo" onerror="this.src='https://ui-avatars.com/api/?name=HC&background=1E4A7A&color=fff'">
        <div class="logo-text">
            Happy Cell
            <small>Admin Panel</small>
        </div>
    </div>
    <div class="sidebar-menu">
        <a href="index.php" class="sidebar-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="stock_in.php" class="sidebar-link active"><i class="fas fa-arrow-circle-down" style="color: #10B981;"></i> Stock In</a>
        <a href="admin_stock_out.php" class="sidebar-link"><i class="fas fa-arrow-circle-up" style="color: #EF4444;"></i> Stock Out</a>
        <a href="return.php" class="sidebar-link"><i class="fas fa-rotate-left" style="color: #F59E0B;"></i> Retur</a>
        
        <div class="sidebar-divider"></div>
        
        <a href="data_barang.php" class="sidebar-link"><i class="fas fa-box"></i> Data Produk</a>
        <a href="penjualan.php" class="sidebar-link"><i class="fas fa-shopping-cart"></i> Transaksi Jual</a>
        <a href="keuangan.php" class="sidebar-link"><i class="fas fa-chart-pie"></i> Analisis Laba</a>
        <a href="manajemen_label.php" class="sidebar-link"><i class="fas fa-print"></i> Cetak Label</a>
        <a href="tukar_tambah.php" class="sidebar-link"><i class="fas fa-exchange-alt"></i> Tukar Tambah</a>
        <a href="service_hp.php" class="sidebar-link"><i class="fas fa-tools"></i> Service HP</a>
    </div>
</div>

<div class="content-wrapper">
    <div class="navbar-top">
        <div class="logo-area">
            <img src="asset/Happy.png" alt="Happy Cell" class="navbar-logo" onerror="this.src='https://ui-avatars.com/api/?name=HC&background=1E4A7A&color=fff'">
            <div class="logo-text">
                Happy Cell
                <small>Admin Panel</small>
            </div>
        </div>
        
        <div class="dropdown">
            <button class="user-badge" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user-shield"></i> <?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 mt-2" style="border-radius: 12px; padding: 8px;">
                <li><a class="dropdown-item fw-semibold" href="kelola_user.php"><i class="fas fa-users-cog me-2"></i> Kelola User</a></li>
                <li><a class="dropdown-item fw-semibold" href="ganti_password.php"><i class="fas fa-key me-2"></i> Ganti Password</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger fw-bold" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Keluar</a></li>
            </ul>
        </div>
    </div>

    <div class="main-wrapper">
        <button class="btn-scan-hero" onclick="openScanner()">
            <i class="fas fa-barcode"></i>
            <span>Ketuk untuk Scan Barcode IMEI</span>
        </button>

        <div class="card-custom">
            <div class="card-title-custom">
                <div><i class="fas fa-keyboard me-2"></i> Input IMEI Manual</div>
            </div>
            <div class="mb-3">

    <label class="fw-bold mb-2">
        Fast Scan IMEI
    </label>

    <input
        type="text"
        id="scanInput"
        class="form-control"
        placeholder="Scan IMEI menggunakan scanner"
        autocomplete="off"
    >

    <small class="text-muted">
        Scanner USB/Bluetooth akan otomatis masuk
    </small>

</div>
            <div class="input-group mb-2">
                <input type="text" id="manualImei" class="form-control" placeholder="Ketik atau paste IMEI" style="border-radius: 12px 0 0 12px;">
                <button class="btn btn-primary" style="background: var(--primary-dongker); border-color: var(--primary-dongker); border-radius: 0 12px 12px 0;" onclick="tambahImeiManual()">
                    <i class="fas fa-plus"></i> Tambah
                </button>
            </div>
            <small class="text-muted">Tekan Enter atau klik Tambah untuk menambahkan IMEI.</small>
        </div>

        <div class="card-custom">
            <div class="card-title-custom">
                <div><i class="fas fa-list-ol me-2"></i> Daftar IMEI Terscan</div>
                <button class="btn btn-sm btn-outline-danger rounded-pill fw-bold" style="font-size: 0.75rem;" onclick="clearImeiList()">Reset</button>
            </div>
            <div id="imeiBatchList">
                <div class="text-center text-muted py-3 small">
                    <i class="fas fa-box-open fs-2 mb-2" style="opacity: 0.5;"></i><br>Belum ada IMEI
                </div>
            </div>
        </div>
        <div class="card-custom">

<div class="card-title-custom">
    <div>
        <i class="fas fa-box me-2"></i>
        Master Produk
    </div>
</div>

<select
    id="masterProduk"
    class="form-select"
>
    <option value="">
        Pilih Produk
    </option>

    <?php foreach($produk as $p): ?>

    <option value="<?= $p['id'] ?>">
        <?= htmlspecialchars(
            $p['nama'].' - '.
            $p['internal_storage'].' - '.
            $p['warna']
        ) ?>
    </option>

    <?php endforeach; ?>

</select>

</div>
        <div class="card-custom">
            <div class="card-title-custom">
                <div><i class="fas fa-mobile-alt me-2"></i> Detail Perangkat</div>
            </div>
            <div class="row g-3">
                <div class="col-12">
                    <div class="form-floating">
                        <input list="namaOpsi" id="nama" class="form-control uppercase" placeholder="Nama">
                        <label>Nama Barang *</label>
                        <datalist id="namaOpsi">
                            <option value="IPHONE 13"><option value="IPHONE 14"><option value="IPHONE 15"><option value="SAMSUNG S23"><option value="SAMSUNG S24"><option value="XIAOMI 14">
                        </datalist>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-floating">
                        <input list="tipeOpsi" id="tipe" class="form-control uppercase" placeholder="Kondisi">
                        <label>Kondisi / Tipe</label>
                        <datalist id="tipeOpsi">
                            <option value="BARU (BNIB)"><option value="SECOND (MULUS)"><option value="EX-INTER"><option value="RESMI IBOX">
                        </datalist>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-floating">
                        <input list="warnaOpsi" id="warna" class="form-control uppercase" placeholder="Warna">
                        <label>Warna</label>
                        <datalist id="warnaOpsi">
                            <option value="HITAM"><option value="PUTIH"><option value="BIRU"><option value="MERAH"><option value="UNGU">
                        </datalist>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-floating">
                        <input list="storageOpsi" id="internal" class="form-control uppercase" placeholder="Storage">
                        <label>Internal Storage</label>
                        <datalist id="storageOpsi">
                            <option value="64GB"><option value="128GB"><option value="256GB"><option value="512GB"><option value="1TB">
                        </datalist>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-floating">
                        <input list="supOpsi" id="supplier" class="form-control uppercase" placeholder="Supplier">
                        <label>Supplier</label>
                        <datalist id="supOpsi">
                            <option value="DISTRIBUTOR PUSAT"><option value="TUKAR TAMBAH USER"><option value="TAM">
                        </datalist>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-floating">
                        <input type="text" id="keterangan" class="form-control" placeholder="Keterangan tambahan">
                        <label>Keterangan</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-custom">
            <div class="card-title-custom">
                <div><i class="fas fa-tags me-2"></i> Harga & Dokumentasi</div>
            </div>
            <div class="row g-3">
                <div class="col-6">
                    <div class="form-floating">
                        <input type="text" id="modal" class="form-control" placeholder="0" inputmode="numeric">
                        <label>Harga Modal (Rp) *</label>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-floating">
                        <input type="text" id="harga_jual" class="form-control" placeholder="0" inputmode="numeric">
                        <label>Harga Jual (Rp) *</label>
                    </div>
                </div>
                <div class="col-12" id="profitWrap" style="display: none; margin-top: -5px;">
                    <span id="profitTxt" class="profit-badge"></span>
                </div>
                <div class="col-12">
                    <div class="form-floating">
                        <input type="date" id="tanggal" class="form-control">
                        <label>Tanggal Masuk</label>
                    </div>
                </div>
                <div class="col-12 mt-2">
                    <label class="small text-muted fw-bold mb-2 d-block">Foto Barang (Opsional)</label>
                    <div class="upload-area">
                        <div class="img-preview-box" id="imagePreview">
                            <i class="fas fa-camera text-muted fs-4"></i>
                        </div>
                        <div class="d-flex flex-column gap-2 flex-grow-1">
                            <button class="btn btn-sm btn-outline-secondary w-100 rounded-pill fw-semibold" id="btnGallery"><i class="fas fa-folder me-2"></i> Pilih File</button>
                            <button class="btn btn-sm btn-danger rounded-pill fw-semibold" id="btnRemoveImage" style="display:none;"><i class="fas fa-trash-alt me-1"></i> Hapus</button>
                        </div>
                    </div>
                    <input type="file" id="fileInput" accept="image/*" hidden>
                </div>
            </div>
        </div>

        <div class="summary-bar">
            <button class="btn-save" onclick="simpanBatch()">
                <i class="fas fa-save"></i> SIMPAN BARANG
            </button>
        </div>
    </div>
</div>

<nav class="bottom-nav">
    <a href="index.php" class="nav-item">
        <i class="fas fa-th-large"></i><span>Dashboard</span>
    </a>
    <a href="stock_in.php" class="nav-item active">
        <i class="fas fa-arrow-circle-down" style="color: #10B981;"></i><span>Stock In</span>
    </a>
    <a href="admin_stock_out.php" class="nav-item">
        <i class="fas fa-arrow-circle-up" style="color: #EF4444;"></i><span>Stock Out</span>
    </a>
    <a href="return.php" class="nav-item">
        <i class="fas fa-rotate-left" style="color: #F59E0B;"></i><span>Retur</span>
    </a>
    <div class="nav-item" id="moreMenuBtn" role="button">
        <i class="fas fa-bars"></i><span>Menu</span>
    </div>
</nav>

<div class="more-menu-popup" id="moreMenuPopup">
    <a href="data_barang.php"><i class="fas fa-box"></i> Data Produk</a>
    <a href="penjualan.php"><i class="fas fa-shopping-cart"></i> Transaksi Jual</a>
    <a href="keuangan.php"><i class="fas fa-chart-pie"></i> Analisis Laba</a>
    <a href="manajemen_label.php"><i class="fas fa-print"></i> Cetak Label</a>
    <a href="tukar_tambah.php"><i class="fas fa-exchange-alt"></i> Tukar Tambah</a>
    <a href="service_hp.php"><i class="fas fa-tools"></i> Service HP</a>
</div>
<div class="popup-overlay" id="popupOverlay"></div>

<div id="scannerModal">
    <div class="scanner-header">
        <button class="btn-glass" onclick="switchCamera()">
            <i class="fas fa-sync-alt"></i> Kamera
        </button>
        <button class="btn-glass" id="torchBtn" onclick="toggleTorch()" style="display: none;">
            <i class="fas fa-bolt"></i> Senter
        </button>
        <button class="btn-glass bg-danger text-white" onclick="closeScanner()">
            <i class="fas fa-times"></i> Batal
        </button>
    </div>
    <div id="reader"></div>
    <div class="scanner-overlay"></div>
    <div class="scanner-reticle">
        <div class="corner-bottom"></div>
        <div class="scan-line"></div>
    </div>
    <div class="scanner-helper-text">
        Arahkan barcode ke dalam kotak
    </div>
</div>

<div id="loadingOverlay">
    <div class="spinner-border text-light mb-3" style="width: 3rem; height: 3rem;"></div>
    <div class="fw-bold">Menyimpan Data...</div>
</div>

<audio id="beepSound" src="https://www.soundjay.com/buttons/sounds/beep-07.mp3" preload="auto"></audio>

<script>
    let imeiBatch = [];
    let imageFile = null;
    let scanCooldown = false;
    let lastScan = "";
    let currentFacing = 'environment';
    let scannerMode = 'quagga'; 
    let quaggaInitialized = false;
    let isTorchOn = false;
    let track = null; 
    let nativeStream = null; 
    const beep = document.getElementById('beepSound');

    document.getElementById('tanggal').value = new Date().toISOString().split('T')[0];

    // Uppercase text inputs
    document.querySelectorAll('.uppercase').forEach(input => {
        input.addEventListener('input', function() { this.value = this.value.toUpperCase(); });
    });

    // Format Rupiah & Profit
    const formatRp = v => { let n = v.replace(/[^0-9]/g,''); return n ? new Intl.NumberFormat('id-ID').format(n) : ''; };
    const parseRp = v => parseInt(v.replace(/[^0-9]/g, '')) || 0;

    function hitungProfit() {
        let modal = parseRp(document.getElementById('modal').value);
        let jual = parseRp(document.getElementById('harga_jual').value);
        let wrap = document.getElementById('profitWrap');
        let txt = document.getElementById('profitTxt');

        if(modal > 0 && jual > 0) {
            let profit = jual - modal;
            wrap.style.display = 'block';
            txt.innerHTML = `Estimasi Profit: Rp ${new Intl.NumberFormat('id-ID').format(profit)}`;
            if(profit < 0) { txt.className = 'profit-badge bg-danger text-white'; }
            else if(profit < 50000) { txt.className = 'profit-badge bg-warning text-dark'; }
            else { txt.className = 'profit-badge bg-success text-white'; }
        } else { wrap.style.display = 'none'; }
    }

    ['modal','harga_jual'].forEach(id => {
        let el = document.getElementById(id);
        el.addEventListener('input', () => { el.value = formatRp(el.value); hitungProfit(); });
    });

    // Toast UI
    function toast(msg, type='success') {
        let c = document.getElementById('toastContainer') || (()=>{ let d=document.createElement('div'); d.id='toastContainer'; d.className='toast-container'; document.body.appendChild(d); return d; })();
        let icon = type==='success' ? '<i class="fas fa-check-circle text-success fs-5"></i>' : '<i class="fas fa-info-circle text-warning fs-5"></i>';
        if(type==='danger') icon = '<i class="fas fa-times-circle text-danger fs-5"></i>';
        let t = document.createElement('div'); t.className = 'toast-mini';
        t.innerHTML = `${icon} <span>${msg}</span>`;
        c.appendChild(t);
        setTimeout(()=>{ t.style.opacity = '0'; setTimeout(()=>t.remove(), 300); }, 2500);
    }

    // Image Upload
    const fileInput = document.getElementById('fileInput'), imgPreview = document.getElementById('imagePreview'), btnRemove = document.getElementById('btnRemoveImage');
    function handleFile(f) {
        if (f.size > 2000000) { toast("Ukuran foto maksimal 2MB", "danger"); return false; }
        let reader = new FileReader();
        reader.onload = e => { imgPreview.innerHTML = `<img src="${e.target.result}">`; btnRemove.style.display='block'; };
        reader.readAsDataURL(f); imageFile = f; return true;
    }
    fileInput.onchange = e => { if(e.target.files[0]) handleFile(e.target.files[0]); };
    document.getElementById('btnGallery').onclick = ()=> fileInput.click();
    btnRemove.onclick = () => { imgPreview.innerHTML='<i class="fas fa-camera text-muted fs-4"></i>'; fileInput.value=''; imageFile=null; btnRemove.style.display='none'; };

    // IMEI Logic
    async function tambahImei(imei) {
                function validasiIMEI(imei){
            return /^[0-9]{15}$/.test(imei);
        }
        if(!validasiIMEI(imei)){
            toast(
                'IMEI harus 15 digit angka',
                'danger'
            );
            return;
        }
        if (imeiBatch.includes(imei)) { toast("IMEI sudah terscan","warning"); return; }
        try {
            let res = await fetch(`../api/cek_imei?imei=${imei}`);
            let data = await res.json();
            if (data.exists) { toast(`IMEI ${imei} sudah ada di DB!`,"danger"); return; }
        } catch(e) {}
        imeiBatch.push(imei);

renderImei();

toast(`IMEI Ditambahkan`);

document
.getElementById('scanInput')
.focus();
    }

    function tambahImeiManual() {
        const input = document.getElementById('manualImei');
        const val = input.value.trim().toUpperCase();
        if (val) { tambahImei(val); input.value = ''; input.focus(); }
    }
    document.getElementById('manualImei').addEventListener('keypress', function(e) { if (e.key === 'Enter') { e.preventDefault(); tambahImeiManual(); }});

    function renderImei() {
        let c = document.getElementById('imeiBatchList');
        if (!imeiBatch.length) { c.innerHTML='<div class="text-center text-muted py-3 small"><i class="fas fa-box-open fs-2 mb-2" style="opacity: 0.5;"></i><br>Belum ada IMEI</div>'; return; }
        c.innerHTML = imeiBatch.map((v,i)=>`<span class="imei-chip"><i class="fas fa-barcode"></i> ${v} <i class="fas fa-times-circle btn-del" onclick="hapusImei(${i})"></i></span>`).join('');
    }
    window.hapusImei = i => { imeiBatch.splice(i,1); renderImei(); };
    window.clearImeiList = () => { imeiBatch=[]; renderImei(); };

    // Save Data
    async function simpanBatch() {
        if (!imeiBatch.length) return toast("Harap scan atau input minimal 1 IMEI","danger");
        let nama = document.getElementById('nama').value.trim();
        if (!nama || parseRp(document.getElementById('modal').value) === 0) return toast("Nama dan Harga Modal wajib diisi!","danger");
        
        let fd = new FormData();
        fd.append('imei_list', JSON.stringify(imeiBatch));
        ['nama','tipe','warna','internal','supplier','keterangan'].forEach(id => {
            let val = document.getElementById(id).value.trim();
            if (id !== 'keterangan') val = val.toUpperCase();
            fd.append(id, val);
        });
        fd.append('status', 'READY');
        fd.append('tanggal', document.getElementById('tanggal').value);
        fd.append('modal', parseRp(document.getElementById('modal').value));
        fd.append('harga_jual', parseRp(document.getElementById('harga_jual').value));
        if (imageFile) fd.append('gambar', imageFile);
        if(
            !confirm(
                'Pastikan data sudah benar. Lanjut simpan?'
            )
        ){
            return;
        }
        document.getElementById('loadingOverlay').style.display='flex';
        try {
            let res = await fetch('../api/insert_barang_batch.php', { method:'POST', body:fd });
            let data = await res.json();
            document.getElementById('loadingOverlay').style.display='none';
            if (data.status==='success') { toast("Data berhasil disimpan!"); setTimeout(()=>location.reload(),1500); }
            else toast(data.msg||"Gagal menyimpan","danger");
        } catch(e) { document.getElementById('loadingOverlay').style.display='none'; toast("Koneksi Error. Cek jaringan.","danger"); }
    }

    // Scanner Logic (Native & Quagga)
    function canUseBarcodeDetector() { return ('BarcodeDetector' in window) && ('getUserMedia' in navigator.mediaDevices); }
    async function updateTorchAvailability() {
        let videoTrack = null;
        if (scannerMode === 'native' && nativeStream) videoTrack = nativeStream.getVideoTracks()[0];
        else if (scannerMode === 'quagga' && quaggaInitialized) {
            const stream = Quagga.CameraAccess.getActiveStream();
            if (stream) videoTrack = stream.getVideoTracks()[0];
        }
        const torchBtn = document.getElementById('torchBtn');
        if (videoTrack) {
            track = videoTrack;
            const capabilities = track.getCapabilities();
            torchBtn.style.display = capabilities.torch ? 'flex' : 'none';
        } else { torchBtn.style.display = 'none'; }
    }

    function toggleTorch() {
        if (!track) return;
        isTorchOn = !isTorchOn;
        track.applyConstraints({ advanced: [{ torch: isTorchOn }] }).catch(err => { toast('Gagal menyalakan senter', 'error'); isTorchOn = false; });
        const torchIcon = document.querySelector('#torchBtn i');
        if (isTorchOn) { torchIcon.classList.replace('fa-bolt', 'fa-bolt-slash'); document.getElementById('torchBtn').style.background = 'rgba(255, 255, 255, 0.5)'; } 
        else { torchIcon.classList.replace('fa-bolt-slash', 'fa-bolt'); document.getElementById('torchBtn').style.background = 'rgba(255, 255, 255, 0.2)'; }
    }

    async function startNativeScanner(facing) {
        const readerElement = document.getElementById('reader');
        readerElement.innerHTML = '';
        const video = document.createElement('video');
        video.setAttribute('autoplay', ''); video.setAttribute('playsinline', ''); video.setAttribute('muted', '');
        video.style.width = '100%'; video.style.height = '100%'; video.style.objectFit = 'cover';
        readerElement.appendChild(video);

        const constraints = { video: { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false };
        nativeStream = await navigator.mediaDevices.getUserMedia(constraints);
        video.srcObject = nativeStream; await video.play();

        const barcodeDetector = new BarcodeDetector({ formats: ['code_128', 'ean_13', 'ean_8', 'code_39', 'upc_a'] });
        const detectLoop = async () => {
            if (!nativeStream || !video.readyState) return;
            try {
                const barcodes = await barcodeDetector.detect(video);
                if (barcodes.length > 0 && !scanCooldown) {
                    const code = barcodes[0].rawValue;
                    if (code !== lastScan) {
                        scanCooldown = true; lastScan = code; beep.play().catch(() => {});
                        document.getElementById('scannerModal').classList.add('scanner-success');
                        setTimeout(() => {
                            tambahImei(code); closeScanner();
                            setTimeout(() => { scanCooldown = false; lastScan = ""; }, 2000);
                        }, 400); return;
                    }
                }
            } catch (err) {}
            if (nativeStream) requestAnimationFrame(detectLoop);
        };
        detectLoop();
    }

    function stopNativeScanner() {
        if (nativeStream) { nativeStream.getTracks().forEach(t => t.stop()); nativeStream = null; }
        document.getElementById('reader').innerHTML = '';
    }

    function startQuagga(facing) {
        if (quaggaInitialized) { Quagga.stop(); Quagga.offDetected(); quaggaInitialized = false; }
        Quagga.init({
            inputStream: { name: "Live", type: "LiveStream", target: document.querySelector('#reader'), constraints: { facingMode: facing }, area: { top: "25%", right: "15%", left: "15%", bottom: "30%" } },
            decoder: { readers: ["code_128_reader", "ean_reader", "ean_8_reader", "code_39_reader", "upc_reader"] },
            locator: { patchSize: "medium", halfSample: false }, numOfWorkers: navigator.hardwareConcurrency || 4, frequency: 10, locate: true
        }, (err) => {
            if (err) { toast('Kamera tidak diizinkan atau error', 'error'); closeScanner(); return; }
            quaggaInitialized = true; Quagga.start();
        });
        Quagga.offDetected();
        Quagga.onDetected((result) => {
            let code = result.codeResult.code;
            if (!scanCooldown && code !== lastScan) {
                scanCooldown = true; lastScan = code; beep.play().catch(() => {});
                document.getElementById('scannerModal').classList.add('scanner-success');
                setTimeout(() => {
                    tambahImei(code); closeScanner();
                    setTimeout(() => { scanCooldown = false; lastScan = ""; }, 2000);
                }, 400);
            }
        });
    }

    async function startScanner(facing) {
        if (scannerMode === 'native' && nativeStream) stopNativeScanner();
        else if (scannerMode === 'quagga' && quaggaInitialized) { Quagga.stop(); Quagga.offDetected(); quaggaInitialized = false; }
        
        if (canUseBarcodeDetector()) {
            try { await startNativeScanner(facing); scannerMode = 'native'; } 
            catch (e) { startQuagga(facing); scannerMode = 'quagga'; }
        } else { startQuagga(facing); scannerMode = 'quagga'; }
        await updateTorchAvailability();
    }

    function openScanner() {
        document.getElementById('scannerModal').style.display = 'block';
        document.getElementById('scannerModal').classList.remove('scanner-success');
        scanCooldown = false; lastScan = ""; isTorchOn = false;
        const torchIcon = document.querySelector('#torchBtn i');
        if(torchIcon) { torchIcon.classList.remove('fa-bolt-slash'); torchIcon.classList.add('fa-bolt'); document.getElementById('torchBtn').style.background = 'rgba(255, 255, 255, 0.2)'; }
        startScanner(currentFacing);
    }

    function closeScanner() {
        document.getElementById('scannerModal').style.display = 'none';
        if (track && isTorchOn) track.applyConstraints({ advanced: [{ torch: false }] }).catch(() => {});
        if (scannerMode === 'native') stopNativeScanner();
        else if (scannerMode === 'quagga' && quaggaInitialized) { Quagga.stop(); Quagga.offDetected(); quaggaInitialized = false; }
        track = null; isTorchOn = false;
    }

    function switchCamera() {
        currentFacing = (currentFacing === 'environment') ? 'user' : 'environment';
        if (track && isTorchOn) { track.applyConstraints({ advanced: [{ torch: false }] }).catch(() => {}); isTorchOn = false; document.getElementById('torchBtn').style.background = 'rgba(255, 255, 255, 0.2)'; }
        startScanner(currentFacing);
    }

    // Popup Menu Lainnya (Mobile)
    const moreBtn = document.getElementById('moreMenuBtn'), popup = document.getElementById('moreMenuPopup'), overlay = document.getElementById('popupOverlay');
    if(moreBtn) { moreBtn.addEventListener('click', function(e) { e.stopPropagation(); popup.classList.toggle('show'); overlay.classList.toggle('show'); }); }
    if(overlay) { overlay.addEventListener('click', function() { popup.classList.remove('show'); overlay.classList.remove('show'); }); }
    document.addEventListener('click', function(e) { if (popup && !popup.contains(e.target) && e.target !== moreBtn && !moreBtn.contains(e.target)) { popup.classList.remove('show'); overlay.classList.remove('show'); }});

    window.onload = () => {

    document
    .getElementById('scanInput')
    .focus();

};
const scanInput =
document.getElementById('scanInput');

scanInput.addEventListener(
'keydown',
async function(e){

    if(e.key === 'Enter')
    {
        e.preventDefault();

        let imei =
        this.value.trim();

        if(imei)
        {
            await tambahImei(imei);
        }

        this.value='';

        this.focus();
    }

});

document
.getElementById('masterProduk')
.addEventListener(
'change',
async function(){

    let id = this.value;

    if(!id) return;

    let res =
    await fetch(
        '../api/get_produk.php?id='
        + id
    );

    let json =
    await res.json();

    if(json.status !== 'success')
    {
        return;
    }

    let p = json.data;

    document.getElementById('nama').value =
    p.nama;

    document.getElementById('tipe').value =
    p.tipe;

    document.getElementById('warna').value =
    p.warna;

    document.getElementById('internal').value =
    p.internal_storage;

    document.getElementById('modal').value =
    new Intl.NumberFormat('id-ID')
    .format(p.modal_default);

    document.getElementById('harga_jual').value =
    new Intl.NumberFormat('id-ID')
    .format(p.harga_jual_default);

    hitungProfit();

});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>